# scripts/scrape_audible.py

from audiblescrapernct.load_config import load_config
from audiblescrapernct.scraper import launch_scraper

def main() -> None:
    """
    Entry point for scraping Audible library.
    """
    try:
        config = load_config()
    except Exception as e:
        print(f"❌ Could not load configuration. Exiting.\nDetails: {repr(e)}")
        return

    try:
        launch_scraper(config)
    except Exception as e:
        print(f"❌ Scraping failed due to unexpected error.\nDetails: {repr(e)}")
    else:
        print("✅ Scraping completed successfully!")

if __name__ == "__main__":
    main()
